# TOYOS Scheduler Preemption Branch Goal

Scope: only `D:\codex\generated\toy-os-demo`

Do not modify:
- `D:\codex\orchestrator-mvp\app`
- `D:\codex\orchestrator-mvp\runtime`
- `D:\codex\orchestrator-mvp\tools`
- MetaForge control-layer routing/runtime code

## Why this branch now

Lane A paging smoke/stage2 probes are already present and gated in `kernel.c`. The next highest-signal unfinished lane in `TOYOS_FACTORY_BRANCH_GOALS.md` is scheduler evolution toward timer-driven preemption with a unified ring3 return model.

Current in-repo anchors show a split return path:

- `src/isr_stub.asm`:
  - syscall path (`isr_syscall_stub`) conditionally performs `ret` when `scheduler_ring3_return_requested != 0`
  - IRQ/default paths always complete via `iretd`
- `src/scheduler.c`:
  - exports `scheduler_ring3_return_requested`
  - stores `scheduler_ring3_saved_esp` and callee-saved registers for the syscall-assisted return path

This works for cooperative yield/exit, but it is an unstable foundation for preemptive timer-context resumes.

## Branch goal

Create a bounded migration plan that preserves current boot/user probes while enabling a single return mechanism usable by both syscall and timer IRQ flows.

Success criteria:

1. Syscall return and timer preemption both restore user context through one shared contract.
2. Existing syscall ABI numbers remain unchanged.
3. Existing stage1/stage2 paging and filesystem regression markers remain green.
4. Migration can be rolled back with one compile-time gate.

## Implementation slices (ToyOS-only)

### Slice 1: capture contract doc + data shape lock

- Add a scheduler context frame structure in `include/scheduler.h` for explicit saved state ownership.
- Keep legacy globals during transition, but map them into the new structure.
- No behavior change in this slice.

### Slice 2: ISR unification gate

- Introduce a gate macro (example: `TOYOS_EXPERIMENTAL_PREEMPT_UNIFIED_RETURN`) in assembly/C build flags.
- Under the gate, route `isr_syscall_stub` and `isr_irq0_stub` through one common resume tail.
- Keep legacy syscall-only `ret` behavior when the gate is off.

### Slice 3: scheduler timer preemption handshake

- In `src/scheduler.c`, add explicit preemption request/ack markers tied to tick dispatch.
- Ensure ring3-active transitions are set/cleared only in one place.
- Preserve current process-state enum values; no new scheduler states in this branch.

### Slice 4: regression expansion

- Extend `tools/generic_qemu_smoke.json` with one gated case that requires:
  - timer IRQ marker after ring3 entry
  - unified return marker
  - continued shell/probe completion marker
- Keep existing smoke jobs unchanged.

## Risk list

1. ABI drift risk:
- Touching syscall wrappers can accidentally remap syscall IDs.
- Mitigation: no syscall number changes; static check against `TOYOS_SYSCALL_INVENTORY_SUMMARY.md`.

2. context-corruption risk:
- Mixed `ret`/`iretd` semantics can clobber frame expectations.
- Mitigation: gate-on path emits deterministic debug markers before and after restore.

3. paging interaction risk:
- stage1/stage2 paging relies on stable kernel/user transition assumptions.
- Mitigation: run existing stage1/stage2 smoke lanes unchanged before enabling the new gate by default.

4. starvation/regression risk:
- timer preemption can regress cooperative workloads.
- Mitigation: keep current round-robin dispatch rules; only alter return mechanism in this branch.

## Verification checklist

Static checks:

1. `src/isr_stub.asm` contains one gated unified return tail used by syscall and timer paths.
2. `src/scheduler.c` no longer requires syscall-only return special-casing when gate is enabled.
3. syscall constants are unchanged from `TOYOS_SYSCALL_INVENTORY_SUMMARY.md`.

Runtime checks (QEMU/debugcon):

1. baseline smoke still passes with gate disabled.
2. unified-return smoke passes with gate enabled.
3. stage1 paging smoke and stage2 address-space probe continue to pass.
4. user probe completion marker still emitted.

## Out of scope for this branch

- ELF loader feature expansion.
- control-plane or runtime-route modifications.
- platform lock/routing fixes outside ToyOS workspace.

## Deliverable type

Branch-goal artifact only (proposal-safe). Implementation patches should be staged incrementally after this branch goal is accepted.
