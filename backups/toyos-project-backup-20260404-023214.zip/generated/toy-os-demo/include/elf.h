#ifndef ELF_H
#define ELF_H

#include <stddef.h>
#include <stdint.h>

typedef enum {
    ELF_VALIDATE_OK = 0,
    ELF_VALIDATE_NULL_INPUT = 1,
    ELF_VALIDATE_TRUNCATED_HEADER = 2,
    ELF_VALIDATE_BAD_MAGIC = 3,
    ELF_VALIDATE_UNSUPPORTED_CLASS = 4,
    ELF_VALIDATE_UNSUPPORTED_ENDIAN = 5,
    ELF_VALIDATE_BAD_IDENT_VERSION = 6,
    ELF_VALIDATE_UNSUPPORTED_MACHINE = 7,
    ELF_VALIDATE_UNSUPPORTED_TYPE = 8,
    ELF_VALIDATE_BAD_VERSION = 9,
    ELF_VALIDATE_MISSING_ENTRY = 10,
    ELF_VALIDATE_MISSING_PROGRAM_HEADERS = 11,
    ELF_VALIDATE_BAD_PROGRAM_HEADER_SIZE = 12,
    ELF_VALIDATE_TRUNCATED_PROGRAM_HEADERS = 13,
    ELF_VALIDATE_UNSUPPORTED_SEGMENT = 14,
    ELF_VALIDATE_BAD_SEGMENT_SIZES = 15,
    ELF_VALIDATE_TRUNCATED_SEGMENT_DATA = 16,
    ELF_VALIDATE_BAD_SEGMENT_RANGE = 17,
    ELF_VALIDATE_OVERLAPPING_SEGMENTS = 18,
    ELF_VALIDATE_ENTRY_OUTSIDE_SEGMENTS = 19,
    ELF_VALIDATE_ENTRY_NOT_EXECUTABLE = 20,
    ELF_VALIDATE_TOO_MANY_SEGMENTS = 21,
    ELF_VALIDATE_PREPARE_PAGE_LIMIT = 22,
    ELF_VALIDATE_PREPARE_ALLOC_FAILED = 23,
    ELF_VALIDATE_PREPARE_COPY_FAILED = 24
} elf_validation_code_t;

typedef struct {
    uintptr_t entry_address;
    uintptr_t image_base;
    uintptr_t image_limit;
    uint32_t loadable_segments;
    uint32_t image_pages;
} elf_image_info_t;

#define ELF_LOAD_PLAN_MAX_SEGMENTS 16u

typedef struct {
    uint32_t file_offset;
    uint32_t file_size;
    uint32_t memory_size;
    uint32_t flags;
    uintptr_t virtual_address;
    uintptr_t virtual_limit;
} elf_load_segment_t;

typedef struct {
    elf_image_info_t image;
    uint32_t segment_count;
    elf_load_segment_t segments[ELF_LOAD_PLAN_MAX_SEGMENTS];
} elf_load_plan_t;

#define ELF_PREPARED_IMAGE_MAX_PAGES 64u

typedef struct {
    elf_image_info_t image;
    uintptr_t staged_base;
    uint32_t page_count;
    void* pages[ELF_PREPARED_IMAGE_MAX_PAGES];
} elf_prepared_image_t;

int elf_validate_image(const uint8_t* image, size_t length, elf_image_info_t* out_info, elf_validation_code_t* out_code);
int elf_prepare_load_plan(const uint8_t* image, size_t length, elf_load_plan_t* out_plan, elf_validation_code_t* out_code);
int elf_prepare_image(const uint8_t* image, size_t length, elf_prepared_image_t* out_prepared, elf_validation_code_t* out_code);
void elf_release_prepared_image(elf_prepared_image_t* prepared);

#endif
