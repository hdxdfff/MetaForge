#ifndef PAGING_H
#define PAGING_H

#include <stddef.h>
#include <stdint.h>

#ifndef TOYOS_EXPERIMENTAL_PAGING_STAGE1
#define TOYOS_EXPERIMENTAL_PAGING_STAGE1 0
#endif

#ifndef TOYOS_EXPERIMENTAL_PAGING_STAGE2
#define TOYOS_EXPERIMENTAL_PAGING_STAGE2 0
#endif

typedef struct {
    uintptr_t directory_physical;
    uintptr_t user_lower_bound;
    uintptr_t user_upper_bound;
    uint32_t generation;
    uint8_t active;
} paging_address_space_t;

void paging_initialize(void);
int paging_stage1_smoke_enable(void);
uint8_t paging_enabled(void);
size_t paging_mapped_megabytes(void);
int paging_user_accessible_range(uintptr_t address, size_t size, uint8_t write_access);
uintptr_t paging_directory_address(void);
int paging_address_space_create(paging_address_space_t* out_space);
int paging_address_space_activate(paging_address_space_t* space);
void paging_address_space_destroy(paging_address_space_t* space);

#endif
