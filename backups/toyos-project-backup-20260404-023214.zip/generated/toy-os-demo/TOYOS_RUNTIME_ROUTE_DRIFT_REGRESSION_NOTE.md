﻿# ToyOS Runtime Route Drift Regression Note

Date: 2026-04-02
Scope: `D:\codex\generated\toy-os-demo` only

## Context

This run attempted to close the previously-open validation step for the invalid syscall assertion by executing a fresh ToyOS build and then running QEMU assertions.

## Reproduction

Command executed from `D:\codex\generated\toy-os-demo`:

```powershell
python D:\codex\orchestrator-mvp\tools\build_toy_os.py --target D:\codex\generated\toy-os-demo
```

Observed result:

- `build ready: True`
- `build success: False`
- `link mode: host-fallback`
- repeated compile failures using `gcc.CMD` with `permission denied while trying to connect to the docker API at npipe:////./pipe/docker_engine`
- assembler failures: `nasm ... stderr: command not found`

## Impact

- Current run cannot produce new runtime QEMU evidence for `qemu_user_probe_assertions`.
- The invalid-syscall marker contract remains statically defined in `tools/generic_qemu_smoke.json` but unverified in this host session.

## Classification

Runtime route drift / workspace execution lock issue.

No platform control-layer files were modified in this run.

## Proposal-only follow-up

1. Ensure host-visible assembler and compiler tools resolve to real binaries (not Docker-proxy wrappers) in this workspace execution context.
2. If wrapper usage is required, restore Docker daemon accessibility for this automation runtime before invoking build/test.
3. Re-run the targeted assertion route after toolchain route restoration:
   - `python D:\codex\orchestrator-mvp\tools\build_toy_os.py --target D:\codex\generated\toy-os-demo`
   - `python D:\codex\orchestrator-mvp\tools\generic_test_runner.py --spec tools/generic_qemu_smoke.json`
4. Confirm presence of `invalid-syscall-status=4294967295` and absence of `invalid-syscall-status=0` in `build/qemu-debug.log` or the generated smoke report.

## Verification performed in this run

- Parsed bootstrap, lane, and regression artifacts.
- Executed build command and captured reproducible failure signature.
- Confirmed no control-layer or orchestrator code modifications.
