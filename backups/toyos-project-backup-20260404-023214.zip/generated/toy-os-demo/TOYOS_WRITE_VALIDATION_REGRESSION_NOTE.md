# ToyOS Write Validation Regression Note

Scope: only `D:\codex\generated\toy-os-demo`

## Why this note exists

Lane C (syscall expansion and argument hardening) has recent probe growth in `kernel.c` and `tools/generic_qemu_smoke.json`.
This note captures the current write-argument negative-case contract so future runs can quickly verify drift.

## Current expected user-probe markers

Pass markers:

- `ToyOS: probe ramfs write zero-length rejected`
- `ToyOS: probe tinyfs write zero-length rejected`
- `ToyOS: probe ramfs write null-payload rejected`
- `ToyOS: probe tinyfs write null-payload rejected`
- `ToyOS: probe ramfs write bounded-no-nul rejected`
- `ToyOS: probe tinyfs write bounded-no-nul rejected`
- `ToyOS: probe ramfs write path-bounded-no-nul rejected`
- `ToyOS: probe tinyfs write path-bounded-no-nul rejected`
- `ToyOS: probe ramfs write declared-over-capacity rejected`
- `ToyOS: probe tinyfs write declared-over-capacity rejected`

Fail markers:

- `ToyOS: probe ramfs write zero-length unexpected`
- `ToyOS: probe tinyfs write zero-length unexpected`
- `ToyOS: probe ramfs write null-payload unexpected`
- `ToyOS: probe tinyfs write null-payload unexpected`
- `ToyOS: probe ramfs write bounded-no-nul unexpected`
- `ToyOS: probe tinyfs write bounded-no-nul unexpected`
- `ToyOS: probe ramfs write path-bounded-no-nul unexpected`
- `ToyOS: probe tinyfs write path-bounded-no-nul unexpected`
- `ToyOS: probe ramfs write declared-over-capacity unexpected`
- `ToyOS: probe tinyfs write declared-over-capacity unexpected`

## Static verification snapshot (this run)

- `kernel.c` contains all pass/fail write-validation markers listed above in `user_probe_log_write_validation_markers`.
- `tools/generic_qemu_smoke.json` contains corresponding pass/fail markers under `qemu_user_probe_assertions`.

## Marker to kernel-branch mapping (triage appendix)

This appendix maps each write-validation marker to the exact probe callsite and the syscall-side rejection path.
Use it to triage runtime logs without re-reading the full kernel flow.

| Marker family | Probe syscall + status variable (`kernel.c`) | Rejection branch in `src/syscall.c` |
| --- | --- | --- |
| `ramfs write zero-length` | `SYSCALL_RAMFS_WRITE` via `zero_length_status` (`kernel.c:266-272`) | `syscall_copy_user_string(... declared_limit == 0)` guard returns invalid (`src/syscall.c:94-96`, reached from `SYSCALL_RAMFS_WRITE` at `src/syscall.c:236-237`) |
| `tinyfs write zero-length` | `SYSCALL_TINYFS_WRITE` via `tinyfs_zero_length_status` (`kernel.c:273-279`) | same zero-limit guard (`src/syscall.c:94-96`), reached from `SYSCALL_TINYFS_WRITE` at `src/syscall.c:250-251` |
| `ramfs write null-payload` | `SYSCALL_RAMFS_WRITE` with `arg1=0` via `ramfs_null_payload_status` (`kernel.c:280-286`) | `syscall_copy_user_string(... user_pointer == NULL)` guard returns invalid (`src/syscall.c:94-96`, reached via `src/syscall.c:236-237`) |
| `tinyfs write null-payload` | `SYSCALL_TINYFS_WRITE` with `arg1=0` via `null_payload_status` (`kernel.c:287-293`) | same null-pointer guard (`src/syscall.c:94-96`), reached via `src/syscall.c:250-251` |
| `ramfs write bounded-no-nul` | `SYSCALL_RAMFS_WRITE` via `bounded_without_nul_status` (`kernel.c:294-300`) | bounded copy loop exhausts `declared_limit` without `'\0'`, returns invalid (`src/syscall.c:101-113`, reached via `src/syscall.c:236-237`) |
| `tinyfs write bounded-no-nul` | `SYSCALL_TINYFS_WRITE` via `tinyfs_bounded_without_nul_status` (`kernel.c:301-307`) | same bounded-no-NUL rejection (`src/syscall.c:101-113`), reached via `src/syscall.c:250-251` |
| `ramfs write path-bounded-no-nul` | `SYSCALL_RAMFS_WRITE` via `ramfs_path_bounded_without_nul_status` (`kernel.c:308-314`) | path copy (`arg0`) exhausts 64-byte declared limit without `'\0'`, invalid (`src/syscall.c:235-237` + helper `src/syscall.c:101-113`) |
| `tinyfs write path-bounded-no-nul` | `SYSCALL_TINYFS_WRITE` via `tinyfs_path_bounded_without_nul_status` (`kernel.c:315-321`) | same bounded path rejection (`src/syscall.c:249-251` + helper `src/syscall.c:101-113`) |
| `ramfs write declared-over-capacity` | `SYSCALL_RAMFS_WRITE` via `ramfs_declared_over_capacity_status` (`kernel.c:322-328`) | explicit `arg2 > sizeof(payload_buffer)` guard returns invalid (`src/syscall.c:232-234`) |
| `tinyfs write declared-over-capacity` | `SYSCALL_TINYFS_WRITE` via `tinyfs_declared_over_capacity_status` (`kernel.c:329-335`) | explicit `arg2 > sizeof(payload_buffer)` guard returns invalid (`src/syscall.c:246-248`) |

Marker emission decision points:

- `rejected` markers are emitted when probe status equals `TOYOS_SYSCALL_STATUS_INVALID` (`kernel.c:337-385`).
- `unexpected` markers are emitted in the corresponding `else` branches (`kernel.c:340,345,350,355,360,365,370,375,380,385`).

Regression-spec parity anchors:

- pass markers are asserted in `tools/generic_qemu_smoke.json:114-123`.
- fail markers are asserted absent via `must_not_contain_markers` in `tools/generic_qemu_smoke.json:136-145`.

## Runtime verification status

- Runtime validation (`make kernel-host` / `make qemu-smoke`) remains blocked in this environment due Docker daemon access failure to `npipe:////./pipe/docker_engine`.
- This is recorded as an environment/workspace-lock issue only; no platform or control-layer files were modified.

## Next recommended step

1. Restore Docker daemon access and run `make kernel-host`.
2. Run `make qemu-smoke`.
3. Confirm all write-validation rejection pass markers appear and no `...unexpected` marker appears.
