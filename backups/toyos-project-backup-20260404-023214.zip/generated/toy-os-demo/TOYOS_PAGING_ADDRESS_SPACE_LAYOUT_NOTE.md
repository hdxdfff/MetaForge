# ToyOS Paging Address Space Layout Note

Scope: only `D:\codex\generated\toy-os-demo`

Do not modify:

- `D:\codex\orchestrator-mvp\app`
- `D:\codex\orchestrator-mvp\runtime`
- `D:\codex\orchestrator-mvp\tools`
- MetaForge OS control or routing logic

## Purpose

Document the current Stage-1/Stage-2 address-space assumptions so paging follow-up work can evolve from explicit invariants instead of implicit behavior.

This note is descriptive and regression-oriented. It does not promote paged ring3 execution to default boot.

## Current layout model (as implemented)

Observed static anchors:

- identity page tables are allocated in `src/paging.c` with `IDENTITY_TABLES=2`, `PAGE_ENTRIES=1024`, `PAGE_SIZE_BYTES=4096`
- current mapped window is therefore `8 MiB` (`paging_mapped_megabytes()`)
- stage1 paging enablement remains gated (`TOYOS_EXPERIMENTAL_PAGING_STAGE1`)
- stage2 address-space ownership remains gated (`TOYOS_EXPERIMENTAL_PAGING_STAGE2`)
- address-space metadata uses `paging_address_space_t` in `include/paging.h`

Effective map contract today:

1. `0x00000000` to `0x007FFFFF` is treated as mapped by the kernel paging helper.
2. user-range checks currently rely on this mapped limit in `paging_user_accessible_range(...)`.
3. stage2 process ownership metadata records lower/upper user bounds but still points to the shared directory scaffold.

## Stage-boundary assumptions

### Stable path (default build)

- paging initialize is not promoted to unconditional boot path
- kernel and user probes keep current stable marker sequence
- syscall ABI numbers and status sentinels remain unchanged

### Stage1 experiment path

- must emit `ToyOS: paging stage1 pre-enable`
- must emit `ToyOS: paging stage1 post-enable`
- must continue through normal boot markers (`filesystems ready`, `kernel services online`)
- fallback/skip markers are failures for stage1-specific regression entries

### Stage2 experiment path

- ownership lifecycle markers must appear:
  - `ToyOS: paging stage2 aspace create`
  - `ToyOS: paging stage2 aspace attach`
  - `ToyOS: paging stage2 aspace release`
- creation/activation/release failure markers remain hard failures in stage2 regression entries
- pointer-policy tightening remains gated and must not silently alter stable path behavior

## Invariants to preserve before per-process split

1. `paging_mapped_megabytes()` must remain non-zero before address-space creation succeeds.
2. address-space `generation` must be non-zero for active ownership.
3. `user_lower_bound <= user_upper_bound` must hold for any stage2 activation attempt.
4. deactivation/destruction must zero ownership fields to keep lifecycle checks deterministic.
5. existing syscall ids in `include/syscall.h` must not be renumbered by paging work.

## Verification checklist (static + runtime)

Static checks:

- confirm `include/paging.h` still defines stage gates and `paging_address_space_t`
- confirm `src/paging.c` still enforces range overflow guard in `paging_user_accessible_range(...)`
- confirm `src/scheduler.c` still emits stage2 attach/release lifecycle markers
- confirm `tools/generic_qemu_smoke.json` retains stage1/stage2 gated regression entries

Runtime checks (when toolchain route is available):

1. run stage1-only smoke spec and verify pre/post-enable markers in order.
2. run stage2-only smoke spec and verify create/attach/release markers with no stage2 failure markers.
3. run baseline smoke spec without stage gates and confirm stable-path marker order unchanged.

## Next recommended implementation step

Introduce a non-default stage2 probe that binds user processes to disjoint teaching ranges (metadata-only at first), then verify syscall pointer-policy behavior against those ranges before any default-path promotion.
