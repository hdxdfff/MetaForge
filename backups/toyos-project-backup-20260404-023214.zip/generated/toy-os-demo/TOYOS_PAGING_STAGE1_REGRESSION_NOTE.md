# ToyOS Paging Stage1 Regression Note

Scope: only `D:\codex\generated\toy-os-demo`

Do not modify:

- `D:\codex\orchestrator-mvp\app`
- `D:\codex\orchestrator-mvp\runtime`
- `D:\codex\orchestrator-mvp\tools`
- MetaForge OS control or routing logic

## Purpose

Capture the current Stage-1 paging smoke contract as implemented in-repo, so regressions can be triaged quickly without re-deriving intent from scattered code paths.

This is a regression note, not a claim that paged ring3 execution is production-ready.

## Current Stage-1 gate contract

Kernel gating path:

- `kernel.c`: `maybe_run_paging_stage1_smoke()` emits:
  - `ToyOS: paging stage1 pre-enable`
  - `ToyOS: paging stage1 post-enable`
  - `ToyOS: paging stage1 fallback panic` (failure path)
  - `ToyOS: paging stage1 skipped (stable path)` (non-experimental build path)

Paging smoke helper:

- `src/paging.c`: `paging_stage1_smoke_enable()`:
  - writes canary
  - calls `paging_initialize()`
  - verifies paging-enabled flag, canary stability, and non-zero paging directory address

QEMU smoke contract:

- `tools/generic_qemu_smoke.json`: `qemu_boot_paging_stage1` test:
  - build command uses `TOYOS_EXPERIMENTAL_PAGING_STAGE1=1`
  - requires pass markers for stage1 pre/post-enable and normal boot continuation
  - treats fallback panic and stable-path skip marker as failures for this specific test

## Verifiable static anchors

1. Marker and gate anchors in `kernel.c`:

- `maybe_run_paging_stage1_smoke`
- `ToyOS: paging stage1 pre-enable`
- `ToyOS: paging stage1 post-enable`
- `ToyOS: paging stage1 fallback panic`
- `ToyOS: paging stage1 skipped (stable path)`

2. Stage-1 helper anchors in `src/paging.c`:

- `paging_stage1_smoke_enable`
- `TOYOS_PAGING_STAGE1_CANARY`
- `paging_initialize`

3. Regression spec anchors in `tools/generic_qemu_smoke.json`:

- `qemu_boot_paging_stage1`
- `TOYOS_EXPERIMENTAL_PAGING_STAGE1=1`
- stage1 pass/fail marker set

## Known limitations (unchanged)

- Default stable path still compiles with Stage-1 paging disabled.
- Current identity mapping remains teaching-oriented and user-flag broad.
- Scheduler/user return model is not yet unified for stable paged ring3 promotion.
- No per-process address-space ownership exists yet.

## Promotion guidance

Keep Stage-1 as a gated regression lane until all are true:

1. runtime smoke is green in current environment;
2. ring3 return path is unified for syscall and timer-preemption evolution;
3. address-space ownership model is defined for processes;
4. pointer validation is aligned with paged permission enforcement goals.
