#include "syscall.h"

#include "idt.h"
#include "io.h"
#include "keyboard.h"
#include "memory.h"
#include "paging.h"
#include "scheduler.h"
#include "terminal.h"
#include "timer.h"
#include "vfs.h"

static uint32_t g_syscall_count = 0;

typedef enum {
    SYSCALL_PTR_READ_ONLY = 1,
    SYSCALL_PTR_WRITE_ONLY = 2,
    SYSCALL_PTR_READ_WRITE = 3,
} syscall_pointer_access_t;

typedef enum {
    SYSCALL_PTR_POLICY_GLOBAL = 0,
    SYSCALL_PTR_POLICY_PROCESS_STAGE2 = 1,
} syscall_pointer_policy_t;

static uint32_t syscall_status_invalid(void) {
    return TOYOS_SYSCALL_STATUS_INVALID;
}

static uint32_t syscall_status_fault(void) {
    return TOYOS_SYSCALL_STATUS_FAULT;
}

static int syscall_validate_user_buffer_with_policy(
    const void* pointer,
    size_t size,
    syscall_pointer_access_t access,
    syscall_pointer_policy_t policy
) {
    uintptr_t address;
    uintptr_t end_address;
    uint8_t write_access = access == SYSCALL_PTR_WRITE_ONLY || access == SYSCALL_PTR_READ_WRITE;
    if (!pointer) {
        return 0;
    }
    if (size == 0) {
        return 0;
    }
    address = (uintptr_t)pointer;
    end_address = address + size - 1u;
    if (end_address < address) {
        return 0;
    }
#if TOYOS_EXPERIMENTAL_PAGING_STAGE2
    if (policy == SYSCALL_PTR_POLICY_PROCESS_STAGE2) {
        const process_t* process = scheduler_current_process();
        if (!process ||
            !process->address_space_present ||
            process->address_space.generation == 0 ||
            process->address_space.active == 0) {
            return 0;
        }
        if (address < process->address_space.user_lower_bound ||
            end_address > process->address_space.user_upper_bound) {
            return 0;
        }
    }
#else
    (void)policy;
#endif
    if (!paging_user_accessible_range(address, size, write_access)) {
        return 0;
    }
    return 1;
}

static syscall_pointer_policy_t syscall_pointer_policy_for_current_process(void) {
#if TOYOS_EXPERIMENTAL_PAGING_STAGE2
    const process_t* process = scheduler_current_process();
    if (process &&
        process->privilege == PROCESS_PRIVILEGE_USER &&
        process->address_space_present &&
        process->address_space.generation != 0 &&
        process->address_space.active != 0) {
        return SYSCALL_PTR_POLICY_PROCESS_STAGE2;
    }
#endif
    return SYSCALL_PTR_POLICY_GLOBAL;
}

static int syscall_validate_user_buffer(const void* pointer, size_t size, syscall_pointer_access_t access) {
    syscall_pointer_policy_t policy = syscall_pointer_policy_for_current_process();
    if (!syscall_validate_user_buffer_with_policy(pointer, size, access, policy)) {
        return 0;
    }
    return 1;
}

static int syscall_validate_user_string_with_limit(const char* pointer, size_t limit, syscall_pointer_access_t access) {
    size_t length = 0;

    if (!pointer) {
        return 0;
    }
    if (limit == 0) {
        return 0;
    }
    while (length < limit) {
        if (!syscall_validate_user_buffer(pointer + length, 1u, access)) {
            return 0;
        }
        if (pointer[length] == '\0') {
            return 1;
        }
        ++length;
    }
    return 0;
}

static int syscall_validate_user_string(const char* pointer, syscall_pointer_access_t access) {
    return syscall_validate_user_string_with_limit(pointer, 256u, access);
}

static size_t syscall_str_copy(char* dest, const char* src, size_t limit) {
    size_t i = 0;
    if (!dest || limit == 0) {
        return 0;
    }
    while (src && src[i] != '\0' && i + 1 < limit) {
        dest[i] = src[i];
        ++i;
    }
    dest[i] = '\0';
    return i;
}

static int syscall_copy_user_string(
    const char* user_pointer,
    char* kernel_buffer,
    size_t kernel_capacity,
    size_t declared_limit,
    syscall_pointer_access_t access
) {
    size_t index = 0;

    if (!user_pointer || !kernel_buffer || kernel_capacity == 0 || declared_limit == 0) {
        return 0;
    }
    if (declared_limit > kernel_capacity) {
        return 0;
    }

    while (index < declared_limit) {
        if (!syscall_validate_user_buffer(user_pointer + index, 1u, access)) {
            return 0;
        }
        kernel_buffer[index] = user_pointer[index];
        if (kernel_buffer[index] == '\0') {
            return 1;
        }
        ++index;
    }

    kernel_buffer[kernel_capacity - 1u] = '\0';
    return 0;
}

static void syscall_debug(const char* text) {
    if (!text) {
        return;
    }
    while (*text) {
        outb(0xE9, (uint8_t)*text++);
    }
    outb(0xE9, (uint8_t)'\r');
    outb(0xE9, (uint8_t)'\n');
}

static uint32_t syscall_handle(uint32_t number, uint32_t arg0, uint32_t arg1, uint32_t arg2, uint32_t arg3) {
    (void)arg3;
    ++g_syscall_count;
    syscall_debug("SYSCALL: entered");

    switch (number) {
        case SYSCALL_WRITE_LOG:
            if (!syscall_validate_user_string((const char*)arg0, SYSCALL_PTR_READ_ONLY)) {
                return syscall_status_invalid();
            }
            syscall_debug((const char*)arg0);
            terminal_set_color(0x0B);
            terminal_write("[syscall] ");
            terminal_writeln((const char*)arg0);
            terminal_set_color(0x0F);
            if (ramfs_write_text("proc/syscall.last", (const char*)arg0) != 0) {
                return syscall_status_fault();
            }
            return TOYOS_SYSCALL_STATUS_OK;
        case SYSCALL_YIELD:
            syscall_debug("SYSCALL: yield requested");
            scheduler_yield_current();
            scheduler_request_ring0_return();
            return TOYOS_SYSCALL_STATUS_OK;
        case SYSCALL_EXIT:
            syscall_debug("SYSCALL: exit requested");
            scheduler_mark_current_exited((int32_t)arg0);
            scheduler_request_ring0_return();
            return TOYOS_SYSCALL_STATUS_OK;
        case SYSCALL_QUERY_PID:
            return scheduler_current_pid();
        case SYSCALL_CONSOLE_WRITE:
            if (!syscall_validate_user_string((const char*)arg0, SYSCALL_PTR_READ_ONLY)) {
                return syscall_status_invalid();
            }
            terminal_write((const char*)arg0);
            return TOYOS_SYSCALL_STATUS_OK;
        case SYSCALL_READ_KEY: {
            int ch = keyboard_read_char();
            return ch < 0 ? syscall_status_invalid() : (uint32_t)ch;
        }
        case SYSCALL_QUERY_TICKS:
            return timer_ticks();
        case SYSCALL_QUERY_HEAP_USED:
            return (uint32_t)memory_heap_used();
        case SYSCALL_QUERY_PAGES_USED:
            return (uint32_t)memory_pages_used();
        case SYSCALL_RAMFS_COUNT:
            return (uint32_t)ramfs_file_count();
        case SYSCALL_TINYFS_COUNT:
            return (uint32_t)tinyfs_file_count();
        case SYSCALL_RAMFS_NAME: {
            const ramfs_file_t* file;
            if (!syscall_validate_user_buffer((void*)arg1, (size_t)arg2, SYSCALL_PTR_WRITE_ONLY)) {
                return syscall_status_invalid();
            }
            file = ramfs_get_at((size_t)arg0);
            if (!file) {
                ((char*)arg1)[0] = '\0';
                return syscall_status_fault();
            }
            return (uint32_t)syscall_str_copy((char*)arg1, file->name, (size_t)arg2);
        }
        case SYSCALL_TINYFS_NAME: {
            const tinyfs_file_t* file;
            if (!syscall_validate_user_buffer((void*)arg1, (size_t)arg2, SYSCALL_PTR_WRITE_ONLY)) {
                return syscall_status_invalid();
            }
            file = tinyfs_get_at((size_t)arg0);
            if (!file) {
                ((char*)arg1)[0] = '\0';
                return syscall_status_fault();
            }
            return (uint32_t)syscall_str_copy((char*)arg1, file->name, (size_t)arg2);
        }
        case SYSCALL_RAMFS_READ:
            if (!syscall_validate_user_string((const char*)arg0, SYSCALL_PTR_READ_ONLY) ||
                !syscall_validate_user_buffer((void*)arg1, (size_t)arg2, SYSCALL_PTR_WRITE_ONLY)) {
                return syscall_status_invalid();
            }
            return ramfs_read_text((const char*)arg0, (char*)arg1, (size_t)arg2) == 0 ? TOYOS_SYSCALL_STATUS_OK : syscall_status_fault();
        case SYSCALL_TINYFS_READ:
            if (!syscall_validate_user_string((const char*)arg0, SYSCALL_PTR_READ_ONLY) ||
                !syscall_validate_user_buffer((void*)arg1, (size_t)arg2, SYSCALL_PTR_WRITE_ONLY)) {
                return syscall_status_invalid();
            }
            return tinyfs_read_text((const char*)arg0, (char*)arg1, (size_t)arg2) == 0 ? TOYOS_SYSCALL_STATUS_OK : syscall_status_fault();
        case SYSCALL_RAMFS_SIZE: {
            size_t file_size = 0;
            if (!syscall_validate_user_string((const char*)arg0, SYSCALL_PTR_READ_ONLY)) {
                return syscall_status_invalid();
            }
            return ramfs_file_size((const char*)arg0, &file_size) == 0 ? (uint32_t)file_size : syscall_status_fault();
        }
        case SYSCALL_TINYFS_SIZE: {
            size_t file_size = 0;
            if (!syscall_validate_user_string((const char*)arg0, SYSCALL_PTR_READ_ONLY)) {
                return syscall_status_invalid();
            }
            return tinyfs_file_size((const char*)arg0, &file_size) == 0 ? (uint32_t)file_size : syscall_status_fault();
        }
        case SYSCALL_RAMFS_WRITE:
        {
            char path_buffer[64];
            char payload_buffer[RAMFS_FILE_CAPACITY];
            if ((size_t)arg2 > sizeof(payload_buffer)) {
                return syscall_status_invalid();
            }
            if (!syscall_copy_user_string((const char*)arg0, path_buffer, sizeof(path_buffer), sizeof(path_buffer), SYSCALL_PTR_READ_ONLY) ||
                !syscall_copy_user_string((const char*)arg1, payload_buffer, sizeof(payload_buffer), (size_t)arg2, SYSCALL_PTR_READ_ONLY)) {
                return syscall_status_invalid();
            }
            syscall_debug("SYSCALL: ramfs write requested");
            return ramfs_write_text(path_buffer, payload_buffer) == 0 ? TOYOS_SYSCALL_STATUS_OK : syscall_status_fault();
        }
        case SYSCALL_TINYFS_WRITE:
        {
            char path_buffer[64];
            char payload_buffer[TINYFS_FILE_CAPACITY];
            if ((size_t)arg2 > sizeof(payload_buffer)) {
                return syscall_status_invalid();
            }
            if (!syscall_copy_user_string((const char*)arg0, path_buffer, sizeof(path_buffer), sizeof(path_buffer), SYSCALL_PTR_READ_ONLY) ||
                !syscall_copy_user_string((const char*)arg1, payload_buffer, sizeof(payload_buffer), (size_t)arg2, SYSCALL_PTR_READ_ONLY)) {
                return syscall_status_invalid();
            }
            syscall_debug("SYSCALL: tinyfs write requested");
            return tinyfs_write_text(path_buffer, payload_buffer) == 0 ? TOYOS_SYSCALL_STATUS_OK : syscall_status_fault();
        }
        default:
            return syscall_status_invalid();
    }
}

static void syscall_interrupt_handler(uint32_t vector, register_frame_t* frame) {
    (void)vector;
    frame->eax = syscall_handle(frame->eax, frame->ebx, frame->ecx, frame->edx, frame->esi);
}

void syscall_initialize(void) {
    register_interrupt_handler(0x80, syscall_interrupt_handler);
}

uint32_t syscall_count(void) {
    return g_syscall_count;
}
