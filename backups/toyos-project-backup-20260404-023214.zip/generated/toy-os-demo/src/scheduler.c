#include "scheduler.h"

#include "gdt.h"
#include "io.h"
#include "memory.h"

extern void scheduler_iret_to_user(uint32_t entry, uint32_t user_stack, uint32_t arg);
uintptr_t scheduler_ring3_saved_esp = 0;
uint32_t scheduler_ring3_return_requested = 0;
uintptr_t scheduler_iret_saved_ebx = 0;
uintptr_t scheduler_iret_saved_esi = 0;
uintptr_t scheduler_iret_saved_edi = 0;
uintptr_t scheduler_iret_saved_ebp = 0;
scheduler_user_return_frame_t scheduler_user_return_frame = {0};

#define MAX_PROCESSES 12
#define PROCESS_STACK_BYTES 4096u

static process_t processes[MAX_PROCESSES];
static size_t current_process_index = 0;
static uint32_t tick_count = 0;
static pid_t next_pid = 1;
static uint8_t ring3_active = 0;
static pid_t ring3_pid = 0;

static void scheduler_sync_user_return_frame(void) {
    scheduler_user_return_frame.ring3_saved_esp = scheduler_ring3_saved_esp;
    scheduler_user_return_frame.ring3_return_requested = scheduler_ring3_return_requested;
    scheduler_user_return_frame.iret_saved_ebx = scheduler_iret_saved_ebx;
    scheduler_user_return_frame.iret_saved_esi = scheduler_iret_saved_esi;
    scheduler_user_return_frame.iret_saved_edi = scheduler_iret_saved_edi;
    scheduler_user_return_frame.iret_saved_ebp = scheduler_iret_saved_ebp;
}

static void scheduler_mark_all_address_spaces_inactive(void) {
#if TOYOS_EXPERIMENTAL_PAGING_STAGE2
    for (size_t i = 0; i < MAX_PROCESSES; ++i) {
        if (processes[i].address_space_present) {
            processes[i].address_space.active = 0;
        }
    }
#endif
}

static void scheduler_clear_address_space(process_t* process) {
    if (!process) {
        return;
    }
    process->address_space.directory_physical = 0;
    process->address_space.user_lower_bound = 0;
    process->address_space.user_upper_bound = 0;
    process->address_space.generation = 0;
    process->address_space.active = 0;
    process->address_space_present = 0;
    process->address_space_owned = 0;
}

static int scheduler_is_loaded_image_process(const process_t* process) {
    return process != 0 &&
           process->privilege == PROCESS_PRIVILEGE_USER &&
           process->launch_kind == PROCESS_LAUNCH_USER_LOADED_IMAGE;
}

static int scheduler_validate_launch_address_space(const process_image_launch_t* launch) {
#if TOYOS_EXPERIMENTAL_PAGING_STAGE2
    uintptr_t mapped_limit;
    uintptr_t image_last_address;

    if (!launch) {
        return 0;
    }
    if (launch->address_space_present == 0) {
        return launch->address_space_owned == 0;
    }

    mapped_limit = (uintptr_t)(paging_mapped_megabytes() * 1024u * 1024u);
    if (mapped_limit == 0) {
        return 0;
    }
    if (launch->address_space.directory_physical == 0 ||
        launch->address_space.generation == 0 ||
        launch->address_space.active != 0 ||
        launch->address_space.user_lower_bound > launch->address_space.user_upper_bound ||
        launch->address_space.user_upper_bound >= mapped_limit) {
        return 0;
    }
    image_last_address = launch->image_limit - 1u;
    if (launch->image_base < launch->address_space.user_lower_bound ||
        image_last_address > launch->address_space.user_upper_bound) {
        return 0;
    }
    if (launch->user_stack_top != 0 &&
        (launch->user_stack_top - 1u < launch->address_space.user_lower_bound ||
         launch->user_stack_top - 1u > launch->address_space.user_upper_bound)) {
        return 0;
    }
    return 1;
#else
    if (!launch) {
        return 0;
    }
    return launch->address_space_present == 0 && launch->address_space_owned == 0;
#endif
}

static void scheduler_debug(const char* text) {
    if (!text) {
        return;
    }
    while (*text) {
        outb(0xE9, (uint8_t)*text++);
    }
    outb(0xE9, (uint8_t)'\r');
    outb(0xE9, (uint8_t)'\n');
}

static process_t* scheduler_find_process_mut(pid_t pid) {
    for (size_t i = 0; i < MAX_PROCESSES; ++i) {
        if (processes[i].pid == pid && (processes[i].active || processes[i].state == PROCESS_EXITED)) {
            return &processes[i];
        }
    }
    return 0;
}

static void scheduler_reset_process(process_t* process) {
    process->pid = 0;
    process->name = 0;
    process->entry = 0;
    process->context = 0;
    process->runs = 0;
    process->priority = 1;
    process->privilege = PROCESS_PRIVILEGE_KERNEL;
    process->state = PROCESS_EXITED;
    process->time_slice = 1;
    process->slice_remaining = 1;
    process->exit_code = 0;
    process->entry_point = 0;
    process->user_entry_point = 0;
    process->kernel_stack_base = 0;
    process->kernel_stack_top = 0;
    process->user_stack_base = 0;
    process->user_stack_top = 0;
    process->image_base = 0;
    process->image_limit = 0;
    process->image_page_count = 0;
    for (uint32_t page_index = 0; page_index < PROCESS_IMAGE_OWNED_PAGE_MAX; ++page_index) {
        process->image_pages[page_index] = 0;
    }
    scheduler_clear_address_space(process);
    process->launch_kind = PROCESS_LAUNCH_KERNEL_ENTRY;
    process->active = 0;
    process->started = 0;
    process->ring3_ready = 0;
}

static int scheduler_attach_process_address_space_from_launch(process_t* process, const process_image_launch_t* launch) {
#if TOYOS_EXPERIMENTAL_PAGING_STAGE2
    if (!process || !launch) {
        return 0;
    }
    if (launch->address_space_present) {
        process->address_space = launch->address_space;
        process->address_space.active = 0;
        process->address_space_present = 1;
        process->address_space_owned = launch->address_space_owned;
        scheduler_debug("ToyOS: paging stage2 aspace attach");
        return 1;
    }
    if (!paging_address_space_create(&process->address_space)) {
        scheduler_debug("ToyOS: paging stage2 aspace create failed");
        scheduler_clear_address_space(process);
        return 0;
    }
    process->address_space_present = 1;
    process->address_space_owned = 1;
    scheduler_debug("ToyOS: paging stage2 aspace create");
    scheduler_debug("ToyOS: paging stage2 aspace attach");
    return 1;
#else
    (void)process;
    (void)launch;
    return 1;
#endif
}

static void scheduler_release_process_address_space(process_t* process) {
#if TOYOS_EXPERIMENTAL_PAGING_STAGE2
    if (!process || !process->address_space_present) {
        return;
    }
    if (!process->address_space_owned) {
        process->address_space.active = 0;
        scheduler_debug("ToyOS: paging stage2 aspace release");
        scheduler_clear_address_space(process);
        return;
    }
    paging_address_space_destroy(&process->address_space);
    if (process->address_space.directory_physical != 0 ||
        process->address_space.generation != 0 ||
        process->address_space.active != 0) {
        scheduler_debug("ToyOS: paging stage2 aspace release failed");
        scheduler_clear_address_space(process);
        return;
    }
    scheduler_debug("ToyOS: paging stage2 aspace release");
    scheduler_clear_address_space(process);
#else
    (void)process;
#endif
}

static void scheduler_release_process_image_pages(process_t* process) {
    if (!process) {
        return;
    }
    for (uint32_t page_index = 0; page_index < process->image_page_count && page_index < PROCESS_IMAGE_OWNED_PAGE_MAX; ++page_index) {
        if (process->image_pages[page_index] != 0) {
            page_free(process->image_pages[page_index]);
            process->image_pages[page_index] = 0;
        }
    }
    process->image_page_count = 0;
}

static void scheduler_release_process_stacks(process_t* process) {
    scheduler_release_process_address_space(process);
    scheduler_release_process_image_pages(process);
    /*
     * Do not free the active kernel/user stack pages here.
     * Exiting a process still unwinds on the same kernel stack frame, so
     * releasing those pages immediately can corrupt the return path and
     * trigger repeatable page faults under stage1 paging.
     */
    process->kernel_stack_base = 0;
    process->kernel_stack_top = 0;
    process->user_stack_base = 0;
    process->user_stack_top = 0;
    process->ring3_ready = 0;
}

void scheduler_initialize(void) {
    current_process_index = 0;
    tick_count = 0;
    next_pid = 1;
    scheduler_sync_user_return_frame();
    for (size_t i = 0; i < MAX_PROCESSES; ++i) {
        scheduler_reset_process(&processes[i]);
    }
}

pid_t scheduler_create_process(const char* name, process_entry_t entry, void* context, process_privilege_t privilege, uint32_t priority, uint32_t time_slice) {
    if (entry == 0) {
        return 0;
    }
    for (size_t i = 0; i < MAX_PROCESSES; ++i) {
        void* kernel_stack;
        void* user_stack;
        if (processes[i].active) {
            continue;
        }

        scheduler_reset_process(&processes[i]);
        kernel_stack = page_alloc();
        if (!kernel_stack) {
            return 0;
        }
        user_stack = 0;
        if (privilege == PROCESS_PRIVILEGE_USER) {
            user_stack = page_alloc();
            if (!user_stack) {
                page_free(kernel_stack);
                return 0;
            }
        }
        processes[i].pid = next_pid++;
        processes[i].name = name;
        processes[i].entry = entry;
        processes[i].context = context;
        processes[i].runs = 0;
        processes[i].priority = priority == 0 ? 1 : priority;
        processes[i].privilege = privilege;
        processes[i].state = PROCESS_READY;
        processes[i].time_slice = time_slice == 0 ? 1 : time_slice;
        processes[i].slice_remaining = processes[i].time_slice;
        processes[i].exit_code = 0;
        processes[i].entry_point = (uintptr_t)entry;
        processes[i].user_entry_point = privilege == PROCESS_PRIVILEGE_USER ? (uintptr_t)entry : 0;
        processes[i].kernel_stack_base = (uintptr_t)kernel_stack;
        processes[i].kernel_stack_top = (uintptr_t)kernel_stack + PROCESS_STACK_BYTES;
        processes[i].user_stack_base = (uintptr_t)user_stack;
        processes[i].user_stack_top = user_stack ? ((uintptr_t)user_stack + PROCESS_STACK_BYTES) : 0;
        processes[i].image_base = 0;
        processes[i].image_limit = 0;
        processes[i].image_page_count = 0;
        for (uint32_t page_index = 0; page_index < PROCESS_IMAGE_OWNED_PAGE_MAX; ++page_index) {
            processes[i].image_pages[page_index] = 0;
        }
        scheduler_clear_address_space(&processes[i]);
#if TOYOS_EXPERIMENTAL_PAGING_STAGE2
        if (privilege == PROCESS_PRIVILEGE_USER) {
            if (!paging_address_space_create(&processes[i].address_space)) {
                page_free(kernel_stack);
                page_free(user_stack);
                scheduler_debug("ToyOS: paging stage2 aspace create failed");
                scheduler_reset_process(&processes[i]);
                return 0;
            }
            processes[i].address_space_present = 1;
            processes[i].address_space_owned = 1;
            scheduler_debug("ToyOS: paging stage2 aspace create");
            scheduler_debug("ToyOS: paging stage2 aspace attach");
        }
#endif
        processes[i].launch_kind = privilege == PROCESS_PRIVILEGE_USER
            ? PROCESS_LAUNCH_USER_COMPILED_STUB
            : PROCESS_LAUNCH_KERNEL_ENTRY;
        processes[i].active = 1;
        processes[i].started = 0;
        processes[i].ring3_ready = privilege == PROCESS_PRIVILEGE_USER && user_stack != 0;
        return processes[i].pid;
    }
    return 0;
}

pid_t scheduler_create_process_from_image(const char* name, const process_image_launch_t* launch, uint32_t priority, uint32_t time_slice) {
    if (!launch ||
        launch->valid == 0 ||
        launch->entry_address == 0 ||
        launch->image_limit <= launch->image_base ||
        launch->image_page_count == 0 ||
        launch->image_page_count > PROCESS_IMAGE_OWNED_PAGE_MAX ||
        !scheduler_validate_launch_address_space(launch)) {
        scheduler_debug("SCHED: image launch invalid");
        return 0;
    }
    for (uint32_t page_index = 0; page_index < launch->image_page_count; ++page_index) {
        if (launch->image_pages[page_index] == 0) {
            scheduler_debug("SCHED: image metadata invalid");
            return 0;
        }
    }
    scheduler_debug("SCHED: image create begin");
    for (size_t i = 0; i < MAX_PROCESSES; ++i) {
        void* kernel_stack;
        void* user_stack = 0;
        uintptr_t user_stack_top = launch->user_stack_top;
        if (processes[i].active) {
            continue;
        }

        scheduler_reset_process(&processes[i]);
        kernel_stack = page_alloc();
        if (!kernel_stack) {
            scheduler_debug("SCHED: image create rejected");
            return 0;
        }
        if (user_stack_top == 0) {
            user_stack = page_alloc();
            if (!user_stack) {
                page_free(kernel_stack);
                scheduler_debug("SCHED: image stack alloc failed");
                return 0;
            }
            user_stack_top = (uintptr_t)user_stack + PROCESS_STACK_BYTES;
        }

        processes[i].pid = next_pid++;
        processes[i].name = name ? name : launch->image_name;
        processes[i].entry = 0;
        processes[i].context = launch->bootstrap_context;
        processes[i].runs = 0;
        processes[i].priority = priority == 0 ? 1 : priority;
        processes[i].privilege = PROCESS_PRIVILEGE_USER;
        processes[i].state = PROCESS_READY;
        processes[i].time_slice = time_slice == 0 ? 1 : time_slice;
        processes[i].slice_remaining = processes[i].time_slice;
        processes[i].exit_code = 0;
        processes[i].entry_point = 0;
        processes[i].user_entry_point = launch->entry_address;
        processes[i].kernel_stack_base = (uintptr_t)kernel_stack;
        processes[i].kernel_stack_top = (uintptr_t)kernel_stack + PROCESS_STACK_BYTES;
        processes[i].user_stack_base = (uintptr_t)user_stack;
        processes[i].user_stack_top = user_stack_top;
        processes[i].image_base = launch->image_base;
        processes[i].image_limit = launch->image_limit;
        processes[i].image_page_count = launch->image_page_count;
        for (uint32_t page_index = 0; page_index < launch->image_page_count; ++page_index) {
            processes[i].image_pages[page_index] = launch->image_pages[page_index];
        }
        if (!scheduler_attach_process_address_space_from_launch(&processes[i], launch)) {
            for (uint32_t page_index = 0; page_index < PROCESS_IMAGE_OWNED_PAGE_MAX; ++page_index) {
                processes[i].image_pages[page_index] = 0;
            }
            processes[i].image_page_count = 0;
            if (kernel_stack) {
                page_free(kernel_stack);
            }
            if (user_stack) {
                page_free(user_stack);
            }
            scheduler_reset_process(&processes[i]);
            scheduler_debug("SCHED: image aspace attach failed");
            return 0;
        }
        processes[i].launch_kind = PROCESS_LAUNCH_USER_LOADED_IMAGE;
        processes[i].active = 1;
        processes[i].started = 0;
        processes[i].ring3_ready = 1;
        scheduler_debug("SCHED: image create success");
        return processes[i].pid;
    }
    scheduler_debug("SCHED: image create rejected");
    return 0;
}

int scheduler_destroy_process(pid_t pid) {
    process_t* process = scheduler_find_process_mut(pid);
    if (!process) {
        return -1;
    }
    scheduler_release_process_stacks(process);
    process->active = 0;
    process->state = PROCESS_EXITED;
    process->exit_code = 0;
    return 0;
}

void scheduler_tick(void) {
    ++tick_count;
    if (MAX_PROCESSES == 0) {
        return;
    }
    process_t* process = &processes[current_process_index];
    if (!process->active || process->state == PROCESS_EXITED || process->state == PROCESS_BLOCKED) {
        current_process_index = (current_process_index + 1) % MAX_PROCESSES;
        return;
    }
    if (process->slice_remaining > 0) {
        --process->slice_remaining;
    }
    if (process->slice_remaining == 0) {
        if (process->state == PROCESS_RUNNING) {
            process->state = PROCESS_READY;
        }
        process->slice_remaining = process->time_slice;
        current_process_index = (current_process_index + 1) % MAX_PROCESSES;
    }
}

int scheduler_enter_user_process(pid_t pid) {
    process_t* process = scheduler_find_process_mut(pid);
    uint32_t previous_esp0;
    if (!process || !process->active || process->privilege != PROCESS_PRIVILEGE_USER || !process->ring3_ready) {
        return -1;
    }
    scheduler_debug("SCHED: enter user start");
    previous_esp0 = gdt_kernel_stack_top();
    current_process_index = (size_t)(process - processes);
    process->state = PROCESS_RUNNING;
    process->started = 1;
    ring3_active = 1;
    ring3_pid = pid;
    scheduler_ring3_return_requested = 0;
    scheduler_sync_user_return_frame();
    gdt_set_kernel_stack((uint32_t)process->kernel_stack_top);
#if TOYOS_EXPERIMENTAL_PAGING_STAGE2
    scheduler_mark_all_address_spaces_inactive();
    if (process->address_space_present &&
        !paging_address_space_activate(&process->address_space)) {
        scheduler_debug("ToyOS: paging stage2 aspace activate failed");
        gdt_set_kernel_stack(previous_esp0);
        ring3_active = 0;
        ring3_pid = 0;
        process->address_space.active = 0;
        if (process->state == PROCESS_RUNNING) {
            process->state = PROCESS_READY;
        }
        return -1;
    }
#endif
    scheduler_debug("SCHED: iret handoff");
    if (scheduler_is_loaded_image_process(process)) {
        scheduler_debug("SCHED: image dispatch");
    }
    scheduler_iret_to_user((uint32_t)process->user_entry_point,
                           (uint32_t)process->user_stack_top,
                           scheduler_is_loaded_image_process(process) ? 0u : (uint32_t)process->context);
    scheduler_debug("SCHED: user returned");
    ring3_active = 0;
    ring3_pid = 0;
    scheduler_sync_user_return_frame();
    __asm__ __volatile__(
        "movw $0x10, %%ax\n"
        "movw %%ax, %%ds\n"
        "movw %%ax, %%es\n"
        "movw %%ax, %%fs\n"
        "movw %%ax, %%gs\n"
        :
        :
        : "ax", "memory"
    );
    process->address_space.active = 0;
    gdt_set_kernel_stack(previous_esp0);
    ++process->runs;
    if (process->state == PROCESS_RUNNING) {
        process->state = PROCESS_READY;
    }
    if (process->state == PROCESS_EXITED) {
        scheduler_release_process_stacks(process);
        process->active = 0;
    }
    return 0;
}

void scheduler_dispatch_once(void) {
    for (size_t offset = 0; offset < MAX_PROCESSES; ++offset) {
        size_t index = (current_process_index + offset) % MAX_PROCESSES;
        process_t* process = &processes[index];
        if (!process->active || process->state == PROCESS_BLOCKED || process->state == PROCESS_EXITED) {
            continue;
        }
        if (process->privilege == PROCESS_PRIVILEGE_KERNEL && process->entry == 0) {
            continue;
        }
        if (process->privilege == PROCESS_PRIVILEGE_USER &&
            !scheduler_is_loaded_image_process(process) &&
            process->entry == 0) {
            continue;
        }
        current_process_index = index;
        if (process->privilege == PROCESS_PRIVILEGE_USER && process->ring3_ready) {
            scheduler_debug("SCHED: dispatch user");
            (void)scheduler_enter_user_process(process->pid);
            return;
        }
        process->state = PROCESS_RUNNING;
        process->started = 1;
        process->entry(process->context);
        ++process->runs;
        if (process->state == PROCESS_RUNNING) {
            process->state = PROCESS_READY;
        }
        if (process->state == PROCESS_EXITED) {
            scheduler_release_process_stacks(process);
            process->active = 0;
        }
        return;
    }
}

void scheduler_run_rounds(uint32_t rounds) {
    for (uint32_t round = 0; round < rounds; ++round) {
        for (size_t i = 0; i < MAX_PROCESSES; ++i) {
            scheduler_dispatch_once();
            scheduler_tick();
        }
    }
}

void scheduler_yield_current(void) {
    processes[current_process_index].slice_remaining = 0;
}

void scheduler_mark_current_exited(int32_t exit_code) {
    processes[current_process_index].exit_code = exit_code;
    processes[current_process_index].state = PROCESS_EXITED;
    processes[current_process_index].active = 0;
}

uint32_t scheduler_ticks(void) {
    return tick_count;
}

pid_t scheduler_current_pid(void) {
    return processes[current_process_index].pid;
}

size_t scheduler_current_index(void) {
    return current_process_index;
}

size_t scheduler_process_count(void) {
    size_t count = 0;
    for (size_t i = 0; i < MAX_PROCESSES; ++i) {
        if (processes[i].pid != 0) {
            ++count;
        }
    }
    return count;
}

uint32_t scheduler_ring3_ready_count(void) {
    uint32_t count = 0;
    for (size_t i = 0; i < MAX_PROCESSES; ++i) {
        if (processes[i].ring3_ready) {
            ++count;
        }
    }
    return count;
}

const process_t* scheduler_get_process(size_t index) {
    if (index >= MAX_PROCESSES || processes[index].pid == 0) {
        return 0;
    }
    return &processes[index];
}

const process_t* scheduler_current_process(void) {
    if (processes[current_process_index].pid == 0) {
        return 0;
    }
    return &processes[current_process_index];
}

void scheduler_request_ring0_return(void) {
    scheduler_ring3_return_requested = 1;
    scheduler_sync_user_return_frame();
}

uint8_t scheduler_ring3_active(void) {
    return ring3_active;
}

void* scheduler_current_user_context(void) {
    if (!ring3_active) {
        return 0;
    }
    return processes[current_process_index].context;
}

scheduler_user_return_frame_t scheduler_get_user_return_frame(void) {
    scheduler_sync_user_return_frame();
    return scheduler_user_return_frame;
}
