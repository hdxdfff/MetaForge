#include "elf.h"
#include "memory.h"

#define ELF_HEADER_SIZE 52u
#define ELF_PROGRAM_HEADER_SIZE 32u
#define ELF_PT_LOAD 1u
#define ELF_PF_X 0x1u
#define ELF_ET_EXEC 2u
#define ELF_MACHINE_I386 3u
#define ELF_PAGE_SIZE 4096u

static uint16_t elf_read_u16(const uint8_t* ptr) {
    return (uint16_t)((uint16_t)ptr[0] | ((uint16_t)ptr[1] << 8));
}

static uint32_t elf_read_u32(const uint8_t* ptr) {
    return (uint32_t)ptr[0] |
           ((uint32_t)ptr[1] << 8) |
           ((uint32_t)ptr[2] << 16) |
           ((uint32_t)ptr[3] << 24);
}

static void elf_set_code(elf_validation_code_t* out_code, elf_validation_code_t code) {
    if (out_code) {
        *out_code = code;
    }
}

static void elf_reset_image_info(elf_image_info_t* out_info) {
    if (!out_info) {
        return;
    }
    out_info->entry_address = 0;
    out_info->image_base = 0;
    out_info->image_limit = 0;
    out_info->loadable_segments = 0;
    out_info->image_pages = 0;
}

static void elf_reset_load_plan(elf_load_plan_t* out_plan) {
    if (!out_plan) {
        return;
    }
    out_plan->image.entry_address = 0;
    out_plan->image.image_base = 0;
    out_plan->image.image_limit = 0;
    out_plan->image.loadable_segments = 0;
    out_plan->image.image_pages = 0;
    out_plan->segment_count = 0;
    for (uint32_t i = 0; i < ELF_LOAD_PLAN_MAX_SEGMENTS; ++i) {
        out_plan->segments[i].file_offset = 0;
        out_plan->segments[i].file_size = 0;
        out_plan->segments[i].memory_size = 0;
        out_plan->segments[i].flags = 0;
        out_plan->segments[i].virtual_address = 0;
        out_plan->segments[i].virtual_limit = 0;
    }
}

static void elf_reset_prepared_image(elf_prepared_image_t* out_prepared) {
    if (!out_prepared) {
        return;
    }
    out_prepared->image.entry_address = 0;
    out_prepared->image.image_base = 0;
    out_prepared->image.image_limit = 0;
    out_prepared->image.loadable_segments = 0;
    out_prepared->image.image_pages = 0;
    out_prepared->staged_base = 0;
    out_prepared->page_count = 0;
    for (uint32_t i = 0; i < ELF_PREPARED_IMAGE_MAX_PAGES; ++i) {
        out_prepared->pages[i] = 0;
    }
}

static void elf_zero_page(uint8_t* page) {
    if (!page) {
        return;
    }
    for (uint32_t i = 0; i < ELF_PAGE_SIZE; ++i) {
        page[i] = 0;
    }
}

static int elf_prepared_write_byte(elf_prepared_image_t* prepared, uintptr_t virtual_address, uint8_t value) {
    uintptr_t relative_offset;
    uint32_t page_index;
    uint32_t page_offset;
    uint8_t* page;

    if (!prepared || virtual_address < prepared->staged_base) {
        return 0;
    }
    relative_offset = virtual_address - prepared->staged_base;
    page_index = (uint32_t)(relative_offset / ELF_PAGE_SIZE);
    page_offset = (uint32_t)(relative_offset % ELF_PAGE_SIZE);
    if (page_index >= prepared->page_count || prepared->pages[page_index] == 0) {
        return 0;
    }
    page = (uint8_t*)prepared->pages[page_index];
    page[page_offset] = value;
    return 1;
}

static int elf_parse_image(
    const uint8_t* image,
    size_t length,
    elf_image_info_t* out_info,
    elf_load_plan_t* out_plan,
    elf_validation_code_t* out_code
) {
    uint32_t phoff;
    uint16_t phentsize;
    uint16_t phnum;
    uintptr_t entry;
    uintptr_t load_starts[ELF_LOAD_PLAN_MAX_SEGMENTS];
    uintptr_t load_ends[ELF_LOAD_PLAN_MAX_SEGMENTS];
    uint32_t load_count = 0;
    uint32_t total_pages = 0;
    uintptr_t image_base = 0;
    uintptr_t image_limit = 0;
    int entry_within_load = 0;
    int entry_within_executable_load = 0;

    elf_set_code(out_code, ELF_VALIDATE_OK);
    elf_reset_image_info(out_info);
    elf_reset_load_plan(out_plan);

    if (!image) {
        elf_set_code(out_code, ELF_VALIDATE_NULL_INPUT);
        return 0;
    }
    if (length < ELF_HEADER_SIZE) {
        elf_set_code(out_code, ELF_VALIDATE_TRUNCATED_HEADER);
        return 0;
    }
    if (image[0] != 0x7Fu || image[1] != 'E' || image[2] != 'L' || image[3] != 'F') {
        elf_set_code(out_code, ELF_VALIDATE_BAD_MAGIC);
        return 0;
    }
    if (image[4] != 1u) {
        elf_set_code(out_code, ELF_VALIDATE_UNSUPPORTED_CLASS);
        return 0;
    }
    if (image[5] != 1u) {
        elf_set_code(out_code, ELF_VALIDATE_UNSUPPORTED_ENDIAN);
        return 0;
    }
    if (image[6] != 1u) {
        elf_set_code(out_code, ELF_VALIDATE_BAD_IDENT_VERSION);
        return 0;
    }
    if (elf_read_u16(&image[16]) != ELF_ET_EXEC) {
        elf_set_code(out_code, ELF_VALIDATE_UNSUPPORTED_TYPE);
        return 0;
    }
    if (elf_read_u16(&image[18]) != ELF_MACHINE_I386) {
        elf_set_code(out_code, ELF_VALIDATE_UNSUPPORTED_MACHINE);
        return 0;
    }
    if (elf_read_u32(&image[20]) != 1u) {
        elf_set_code(out_code, ELF_VALIDATE_BAD_VERSION);
        return 0;
    }

    entry = (uintptr_t)elf_read_u32(&image[24]);
    if (entry == 0) {
        elf_set_code(out_code, ELF_VALIDATE_MISSING_ENTRY);
        return 0;
    }

    phoff = elf_read_u32(&image[28]);
    phentsize = elf_read_u16(&image[42]);
    phnum = elf_read_u16(&image[44]);
    if (phoff == 0u || phnum == 0u) {
        elf_set_code(out_code, ELF_VALIDATE_MISSING_PROGRAM_HEADERS);
        return 0;
    }
    if (phentsize != ELF_PROGRAM_HEADER_SIZE) {
        elf_set_code(out_code, ELF_VALIDATE_BAD_PROGRAM_HEADER_SIZE);
        return 0;
    }
    if ((uint64_t)phoff + ((uint64_t)phentsize * (uint64_t)phnum) > (uint64_t)length) {
        elf_set_code(out_code, ELF_VALIDATE_TRUNCATED_PROGRAM_HEADERS);
        return 0;
    }

    for (uint16_t i = 0; i < phnum; ++i) {
        const uint8_t* ph = &image[phoff + ((size_t)i * phentsize)];
        uint32_t p_type = elf_read_u32(&ph[0]);
        uint32_t p_offset;
        uintptr_t p_vaddr;
        uint32_t p_filesz;
        uint32_t p_memsz;
        uint32_t p_flags;
        uintptr_t segment_end;
        uintptr_t rounded_start;
        uintptr_t rounded_end;
        uint32_t segment_pages;

        if (p_type != ELF_PT_LOAD) {
            elf_set_code(out_code, ELF_VALIDATE_UNSUPPORTED_SEGMENT);
            return 0;
        }
        if (load_count >= ELF_LOAD_PLAN_MAX_SEGMENTS) {
            elf_set_code(out_code, ELF_VALIDATE_TOO_MANY_SEGMENTS);
            return 0;
        }

        p_offset = elf_read_u32(&ph[4]);
        p_vaddr = (uintptr_t)elf_read_u32(&ph[8]);
        p_filesz = elf_read_u32(&ph[16]);
        p_memsz = elf_read_u32(&ph[20]);
        p_flags = elf_read_u32(&ph[24]);

        if (p_memsz == 0u || p_filesz > p_memsz) {
            elf_set_code(out_code, ELF_VALIDATE_BAD_SEGMENT_SIZES);
            return 0;
        }
        if ((uint64_t)p_offset + (uint64_t)p_filesz > (uint64_t)length) {
            elf_set_code(out_code, ELF_VALIDATE_TRUNCATED_SEGMENT_DATA);
            return 0;
        }
        if ((uintptr_t)(UINTPTR_MAX - p_vaddr) < (uintptr_t)p_memsz) {
            elf_set_code(out_code, ELF_VALIDATE_BAD_SEGMENT_RANGE);
            return 0;
        }
        segment_end = p_vaddr + (uintptr_t)p_memsz;
        if (segment_end <= p_vaddr) {
            elf_set_code(out_code, ELF_VALIDATE_BAD_SEGMENT_RANGE);
            return 0;
        }

        for (uint32_t j = 0; j < load_count; ++j) {
            if (!(segment_end <= load_starts[j] || p_vaddr >= load_ends[j])) {
                elf_set_code(out_code, ELF_VALIDATE_OVERLAPPING_SEGMENTS);
                return 0;
            }
        }

        if (entry >= p_vaddr && entry < segment_end) {
            entry_within_load = 1;
            if ((p_flags & ELF_PF_X) != 0u) {
                entry_within_executable_load = 1;
            }
        }

        rounded_start = p_vaddr & ~(uintptr_t)(ELF_PAGE_SIZE - 1u);
        rounded_end = (segment_end + (ELF_PAGE_SIZE - 1u)) & ~(uintptr_t)(ELF_PAGE_SIZE - 1u);
        if (rounded_end <= rounded_start) {
            elf_set_code(out_code, ELF_VALIDATE_BAD_SEGMENT_RANGE);
            return 0;
        }
        segment_pages = (uint32_t)((rounded_end - rounded_start) / ELF_PAGE_SIZE);
        if (segment_pages == 0u || UINT32_MAX - total_pages < segment_pages) {
            elf_set_code(out_code, ELF_VALIDATE_BAD_SEGMENT_RANGE);
            return 0;
        }
        total_pages += segment_pages;

        if (load_count == 0u) {
            image_base = p_vaddr;
            image_limit = segment_end;
        } else {
            if (p_vaddr < image_base) {
                image_base = p_vaddr;
            }
            if (segment_end > image_limit) {
                image_limit = segment_end;
            }
        }
        load_starts[load_count] = p_vaddr;
        load_ends[load_count] = segment_end;
        if (out_plan) {
            out_plan->segments[load_count].file_offset = p_offset;
            out_plan->segments[load_count].file_size = p_filesz;
            out_plan->segments[load_count].memory_size = p_memsz;
            out_plan->segments[load_count].flags = p_flags;
            out_plan->segments[load_count].virtual_address = p_vaddr;
            out_plan->segments[load_count].virtual_limit = segment_end;
        }
        ++load_count;
    }

    if (load_count == 0u) {
        elf_set_code(out_code, ELF_VALIDATE_MISSING_PROGRAM_HEADERS);
        return 0;
    }
    if (!entry_within_load) {
        elf_set_code(out_code, ELF_VALIDATE_ENTRY_OUTSIDE_SEGMENTS);
        return 0;
    }
    if (!entry_within_executable_load) {
        elf_set_code(out_code, ELF_VALIDATE_ENTRY_NOT_EXECUTABLE);
        return 0;
    }

    if (out_info) {
        out_info->entry_address = entry;
        out_info->image_base = image_base;
        out_info->image_limit = image_limit;
        out_info->loadable_segments = load_count;
        out_info->image_pages = total_pages;
    }
    if (out_plan) {
        out_plan->image.entry_address = entry;
        out_plan->image.image_base = image_base;
        out_plan->image.image_limit = image_limit;
        out_plan->image.loadable_segments = load_count;
        out_plan->image.image_pages = total_pages;
        out_plan->segment_count = load_count;
    }
    elf_set_code(out_code, ELF_VALIDATE_OK);
    return 1;
}

int elf_validate_image(const uint8_t* image, size_t length, elf_image_info_t* out_info, elf_validation_code_t* out_code) {
    return elf_parse_image(image, length, out_info, 0, out_code);
}

int elf_prepare_load_plan(const uint8_t* image, size_t length, elf_load_plan_t* out_plan, elf_validation_code_t* out_code) {
    if (!out_plan) {
        elf_set_code(out_code, ELF_VALIDATE_NULL_INPUT);
        return 0;
    }
    return elf_parse_image(image, length, 0, out_plan, out_code);
}

void elf_release_prepared_image(elf_prepared_image_t* prepared) {
    if (!prepared) {
        return;
    }
    for (uint32_t i = 0; i < prepared->page_count && i < ELF_PREPARED_IMAGE_MAX_PAGES; ++i) {
        if (prepared->pages[i]) {
            page_free(prepared->pages[i]);
            prepared->pages[i] = 0;
        }
    }
    elf_reset_prepared_image(prepared);
}

int elf_prepare_image(const uint8_t* image, size_t length, elf_prepared_image_t* out_prepared, elf_validation_code_t* out_code) {
    elf_load_plan_t plan;
    uintptr_t rounded_base;
    uintptr_t rounded_limit;
    uintptr_t rounded_span;
    uint32_t required_pages;

    if (!out_prepared) {
        elf_set_code(out_code, ELF_VALIDATE_NULL_INPUT);
        return 0;
    }
    elf_set_code(out_code, ELF_VALIDATE_OK);
    elf_reset_prepared_image(out_prepared);

    if (!elf_prepare_load_plan(image, length, &plan, out_code)) {
        return 0;
    }

    rounded_base = plan.image.image_base & ~(uintptr_t)(ELF_PAGE_SIZE - 1u);
    if (plan.image.image_limit > (UINTPTR_MAX - (ELF_PAGE_SIZE - 1u))) {
        elf_set_code(out_code, ELF_VALIDATE_BAD_SEGMENT_RANGE);
        return 0;
    }
    rounded_limit = (plan.image.image_limit + (ELF_PAGE_SIZE - 1u)) & ~(uintptr_t)(ELF_PAGE_SIZE - 1u);
    if (rounded_limit <= rounded_base) {
        elf_set_code(out_code, ELF_VALIDATE_BAD_SEGMENT_RANGE);
        return 0;
    }
    rounded_span = rounded_limit - rounded_base;
    if ((rounded_span % ELF_PAGE_SIZE) != 0u) {
        elf_set_code(out_code, ELF_VALIDATE_BAD_SEGMENT_RANGE);
        return 0;
    }
    required_pages = (uint32_t)(rounded_span / ELF_PAGE_SIZE);
    if (required_pages == 0u || required_pages > ELF_PREPARED_IMAGE_MAX_PAGES) {
        elf_set_code(out_code, ELF_VALIDATE_PREPARE_PAGE_LIMIT);
        return 0;
    }

    out_prepared->image = plan.image;
    out_prepared->staged_base = rounded_base;
    out_prepared->page_count = required_pages;
    for (uint32_t i = 0; i < required_pages; ++i) {
        void* page = page_alloc();
        if (!page) {
            elf_set_code(out_code, ELF_VALIDATE_PREPARE_ALLOC_FAILED);
            elf_release_prepared_image(out_prepared);
            return 0;
        }
        out_prepared->pages[i] = page;
        elf_zero_page((uint8_t*)page);
    }

    for (uint32_t seg = 0; seg < plan.segment_count; ++seg) {
        const elf_load_segment_t* segment = &plan.segments[seg];
        for (uint32_t offset = 0; offset < segment->file_size; ++offset) {
            uintptr_t destination = segment->virtual_address + (uintptr_t)offset;
            uint8_t value = image[segment->file_offset + offset];
            if (!elf_prepared_write_byte(out_prepared, destination, value)) {
                elf_set_code(out_code, ELF_VALIDATE_PREPARE_COPY_FAILED);
                elf_release_prepared_image(out_prepared);
                return 0;
            }
        }
    }

    elf_set_code(out_code, ELF_VALIDATE_OK);
    return 1;
}
