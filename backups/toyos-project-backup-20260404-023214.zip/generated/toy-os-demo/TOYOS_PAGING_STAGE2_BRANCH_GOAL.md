# ToyOS Paging Stage 2 Branch Goal

Scope: only `D:\codex\generated\toy-os-demo`

Do not modify:

- `D:\codex\orchestrator-mvp\app`
- `D:\codex\orchestrator-mvp\runtime`
- `D:\codex\orchestrator-mvp\tools`
- MetaForge OS control or routing logic

## Goal

Define the minimum bounded Stage-2 path that prepares ToyOS for per-process address-space ownership while keeping the current stable boot contract intact.

Stage 2 is a preparation branch, not a full virtual-memory rollout.
It should convert current global paging assumptions into explicit process-owned metadata and gated mapping primitives that can be tested without promoting paging to default boot.

## Stage-2 position relative to Stage 1

Current Stage-1 state (already present):

- gated paging smoke enablement exists and is non-default
- identity mapping remains broad and teaching-oriented
- no process-level address-space object exists yet
- syscall pointer checks rely on range checks against a shared mapping window

Stage 2 must add structure and ownership before any stable paged ring3 promotion.

## Current kernel constraints to respect

Observed from current code:

- paging implementation exposes one static directory and identity tables in [`src/paging.c`](D:\codex\generated\toy-os-demo\src\paging.c)
- scheduler process records currently track launch/image metadata but no page-directory ownership in [`include/scheduler.h`](D:\codex\generated\toy-os-demo\include\scheduler.h)
- syscall pointer checks currently call `paging_user_accessible_range(...)` from [`src/syscall.c`](D:\codex\generated\toy-os-demo\src\syscall.c)
- Stage-1 smoke gate and markers are implemented in [`kernel.c`](D:\codex\generated\toy-os-demo\kernel.c)

Implication:

- Stage 2 should introduce ownership metadata and mapping API seams first, then tighten pointer policy behind those seams.

## Stage-2 objectives

1. Introduce per-process address-space metadata without breaking current scheduler API compatibility.
2. Define a minimal paging API for creating, activating, and releasing process address-space records.
3. Keep default boot behavior unchanged unless an explicit Stage-2 experiment gate is enabled.
4. Provide debug markers and regression checks that prove metadata lifecycle works.

## Proposed implementation slices

### Slice A: address-space metadata scaffold

Target files:

- [`include/paging.h`](D:\codex\generated\toy-os-demo\include\paging.h)
- [`src/paging.c`](D:\codex\generated\toy-os-demo\src\paging.c)
- [`include/scheduler.h`](D:\codex\generated\toy-os-demo\include\scheduler.h)

Proposed additions:

- `paging_address_space_t` (opaque or explicit teaching struct)
- bounded API surface:
  - `int paging_address_space_create(paging_address_space_t* out_space)`
  - `int paging_address_space_activate(const paging_address_space_t* space)`
  - `void paging_address_space_destroy(paging_address_space_t* space)`
- scheduler-side metadata fields in `process_t`:
  - address-space handle/id pointer
  - ownership state flag

Boundary:

- do not change syscall numbers
- do not remove current Stage-1 smoke path

### Slice B: process lifecycle integration

Target files:

- [`src/scheduler.c`](D:\codex\generated\toy-os-demo\src\scheduler.c)
- [`kernel.c`](D:\codex\generated\toy-os-demo\kernel.c)

Proposed behavior:

- user process creation path can optionally attach an address-space record under an explicit Stage-2 gate
- process teardown releases any owned address-space record
- context-switch path remains current teaching model, but emits markers when Stage-2 ownership is attached/released

Suggested markers:

- `ToyOS: paging stage2 aspace create`
- `ToyOS: paging stage2 aspace attach`
- `ToyOS: paging stage2 aspace release`

### Slice C: pointer-policy staging seam

Target files:

- [`src/syscall.c`](D:\codex\generated\toy-os-demo\src\syscall.c)

Proposed behavior:

- keep existing pointer checks as compatibility baseline
- add a policy seam so checks can switch between:
  - Stage-1 global-range acceptance
  - Stage-2 process-owned address-space checks
- Stage-2 mode should remain gated and regression-tested before becoming default

Boundary:

- preserve existing syscall IDs and return status constants

## Experiment gate contract

Add one explicit non-default build gate for Stage-2 probes, for example:

- `TOYOS_EXPERIMENTAL_PAGING_STAGE2=1`

Rules:

- default stable build path must remain equivalent to current behavior when gate is off
- Stage-2 tests must fail fast with explicit markers on ownership or activation errors

## Regression plan updates required

Update [`tools/generic_qemu_smoke.json`](D:\codex\generated\toy-os-demo\tools\generic_qemu_smoke.json) with one gated Stage-2 probe entry that requires:

- Stage-2 create marker
- Stage-2 attach marker
- Stage-2 release marker
- normal boot continuation markers

Failure markers should include:

- `ToyOS: paging stage2 aspace create failed`
- `ToyOS: paging stage2 aspace activate failed`
- `ToyOS: paging stage2 aspace release failed`

## Risks and controls

1. Risk: silent ABI drift in scheduler process model.
Control: add metadata fields as additive only; preserve current APIs.

2. Risk: resource leaks on process exit.
Control: mandatory teardown marker and release path in scheduler destroy flow.

3. Risk: false security assumptions from partial pointer checks.
Control: keep Stage-2 pointer checks explicitly gated and documented as non-default.

4. Risk: boot-path instability.
Control: strict experiment gate and fallback to current stable path when disabled.

## Non-goals

Stage 2 does not require:

- full per-process virtual-memory isolation parity
- demand paging, copy-on-write, or swap
- fork/exec/wait process model
- full timer-preemptive context save/restore redesign
- platform routing or control-layer changes

## Acceptance criteria

Stage-2 branch goal is complete only if all are true:

1. Address-space ownership metadata is explicitly defined for user processes.
2. A minimal create/activate/destroy paging API boundary is documented.
3. Stage-2 remains non-default and gated in build/test paths.
4. Regression marker contract includes create, attach, and release lifecycle events.
5. Syscall numbers and current stable runtime contracts remain unchanged.

## Recommended next implementation step

After this branch goal, the highest-signal concrete step is:

1. add the minimal `paging_address_space_*` scaffold (no promotion to default),
2. wire scheduler ownership attach/release for one synthetic user process probe,
3. add a gated QEMU smoke spec entry for Stage-2 ownership markers.
